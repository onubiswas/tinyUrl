package service.com.tinyurl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TinyurlApplicationTests {

	@Test
	void contextLoads() {
	}

}
